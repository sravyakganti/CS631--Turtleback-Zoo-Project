<?php include 'header.php'; ?>

<h2>Management and Reporting</h2>
<ul>
    <li><a href="reporting_functions.php?action=revenue_report">Revenue Report</a></li>
    <li><a href="reporting_functions.php?action=animal_population_report">Animal Population Report</a></li>
    <li><a href="reporting_functions.php?action=top_attractions_report">Top Attractions Report</a></li>
   
</ul>

<?php include 'footer.php'; ?>
