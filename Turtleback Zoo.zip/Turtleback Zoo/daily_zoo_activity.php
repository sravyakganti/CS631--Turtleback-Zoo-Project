<?php include 'header.php'; ?>

<h2>Daily Zoo Activity</h2>
<ul>
    <li><a href="daily_activity_functions.php?action=attendance_and_revenue">Attendance and Revenue</a></li>

    
</ul>

<?php include 'footer.php'; ?>
